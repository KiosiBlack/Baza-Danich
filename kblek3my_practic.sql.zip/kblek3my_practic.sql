-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Ноя 12 2022 г., 13:51
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kblek3my_practic`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Archiw`
--
-- Создание: Ноя 12 2022 г., 10:47
-- Последнее обновление: Ноя 12 2022 г., 10:51
--

DROP TABLE IF EXISTS `Archiw`;
CREATE TABLE `Archiw` (
  `Id_spechialnosy` int(11) NOT NULL,
  `Id_dannie` int(11) NOT NULL,
  `Specialnosy` text NOT NULL,
  `FIO` text NOT NULL,
  `Data_nachalo` date NOT NULL,
  `Data_konec` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Archiw`
--

INSERT INTO `Archiw` (`Id_spechialnosy`, `Id_dannie`, `Specialnosy`, `FIO`, `Data_nachalo`, `Data_konec`) VALUES
(5, 1, 'Главный', 'Петров Петр Петрович', '2022-10-01', '2022-11-01'),
(8, 2, 'Заместитель', 'Иванов Сергей Алексеевич', '2022-11-01', '2022-11-30'),
(6, 3, 'Стажёр ', 'Иванов Иван Иванович', '2022-09-01', '2022-09-30'),
(7, 4, 'Заместитель', 'Сергей Сергеевич Сергеев', '2022-11-01', '2022-11-30');

-- --------------------------------------------------------

--
-- Структура таблицы `Lichnie_dannie`
--
-- Создание: Ноя 12 2022 г., 10:42
-- Последнее обновление: Ноя 12 2022 г., 10:44
--

DROP TABLE IF EXISTS `Lichnie_dannie`;
CREATE TABLE `Lichnie_dannie` (
  `Id_dannie` int(11) NOT NULL,
  `Adres` text NOT NULL,
  `Telefon` varchar(50) NOT NULL,
  `Sp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Lichnie_dannie`
--

INSERT INTO `Lichnie_dannie` (`Id_dannie`, `Adres`, `Telefon`, `Sp`) VALUES
(1, 'ул Пушина', '89113627488', 'Женат'),
(2, 'Ул Колатушкина', '8911648256488', 'Не замужем'),
(3, 'ул. Чернова', '8916382736482', 'Замужем'),
(4, 'Ул Горностаева', '8911637638356', 'Не замужем');

-- --------------------------------------------------------

--
-- Структура таблицы `Specialnosty`
--
-- Создание: Ноя 12 2022 г., 10:37
-- Последнее обновление: Ноя 12 2022 г., 10:39
--

DROP TABLE IF EXISTS `Specialnosty`;
CREATE TABLE `Specialnosty` (
  `Id_spechialnosy` int(11) NOT NULL,
  `Wacanshy` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Specialnosty`
--

INSERT INTO `Specialnosty` (`Id_spechialnosy`, `Wacanshy`) VALUES
(5, 'Бухгалтерия '),
(6, 'Программист'),
(7, 'Экономист'),
(8, 'Секретарь');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Archiw`
--
ALTER TABLE `Archiw`
  ADD UNIQUE KEY `Id_dannie` (`Id_dannie`),
  ADD UNIQUE KEY `Id_spechialnosy` (`Id_spechialnosy`);

--
-- Индексы таблицы `Lichnie_dannie`
--
ALTER TABLE `Lichnie_dannie`
  ADD PRIMARY KEY (`Id_dannie`),
  ADD UNIQUE KEY `Id_dannie` (`Id_dannie`);

--
-- Индексы таблицы `Specialnosty`
--
ALTER TABLE `Specialnosty`
  ADD PRIMARY KEY (`Id_spechialnosy`),
  ADD UNIQUE KEY `Id_spechialnosy` (`Id_spechialnosy`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Lichnie_dannie`
--
ALTER TABLE `Lichnie_dannie`
  MODIFY `Id_dannie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `Specialnosty`
--
ALTER TABLE `Specialnosty`
  MODIFY `Id_spechialnosy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Archiw`
--
ALTER TABLE `Archiw`
  ADD CONSTRAINT `Archiw_ibfk_1` FOREIGN KEY (`Id_spechialnosy`) REFERENCES `Specialnosty` (`Id_spechialnosy`),
  ADD CONSTRAINT `Archiw_ibfk_2` FOREIGN KEY (`Id_dannie`) REFERENCES `Lichnie_dannie` (`Id_dannie`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
